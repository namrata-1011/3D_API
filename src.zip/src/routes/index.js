import express from "express";
import portfolioRoutes from "../modules/portfolio/portfolio.routes.js";
import galleryRoutes from "../modules/gallery/gallery.routes.js";
import mediaRoutes from "../modules/media coverage/media.routes.js";
import testimonialRoutes from "../modules/testimonials/testimonial.routes.js";
import faqRoutes from "../modules/FAQ/faq.routes.js";
import blogRoutes from "../modules/blogs/blog.routes.js";


const router = express.Router();

router.use("/portfolio", portfolioRoutes);
router.use("/gallery", galleryRoutes);
router.use("/testimonials", testimonialRoutes);
router.use("/faq", faqRoutes);
router.use("/media-coverage", mediaRoutes);
router.use("/blogs", blogRoutes);


export default router;