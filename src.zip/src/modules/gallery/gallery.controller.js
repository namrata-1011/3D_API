import {
  createGalleryService,
  getAllGalleryService,
  getGalleryByIdService,
  updateGalleryService,
  deleteGalleryService,
  getGalleryByPortfolioService,
  updateDisplayOrderService,
  toggleGalleryStatusService,
} from "./gallery.service.js";

import { successResponse } from "../../utils/response.js";
import uploadFile from "../../utils/uploadFile.js";

// ==========================
// Create Gallery
// ==========================
export const createGallery = async (req, res, next) => {
  try {
    console.log("BODY =>", req.body);
    console.log("FILES =>", req.files);

    const galleryData = {
      ...req.body,
    };

    // Upload Image
    if (req.files?.image?.[0]) {
      galleryData.image = await uploadFile(
        req.files.image[0].path
      );
    }

    // Upload Video
    if (req.files?.video?.[0]) {
      galleryData.video = await uploadFile(
        req.files.video[0].path
      );
    }

    const data = await createGalleryService(galleryData);

    return successResponse(
      res,
      "Gallery created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get All Gallery
// ==========================
export const getAllGallery = async (req, res, next) => {
  try {
    const data = await getAllGalleryService();

    return successResponse(
      res,
      "Gallery fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get Gallery By ID
// ==========================
export const getGalleryById = async (req, res, next) => {
  try {
    const data = await getGalleryByIdService(req.params.id);

    return successResponse(
      res,
      "Gallery fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Update Gallery
// ==========================
export const updateGallery = async (req, res, next) => {
  try {
    const galleryData = {
      ...req.body,
    };

    // Update Image
    if (req.files?.image?.[0]) {
      galleryData.image = await uploadFile(
        req.files.image[0].path
      );
    }

    // Update Video
    if (req.files?.video?.[0]) {
      galleryData.video = await uploadFile(
        req.files.video[0].path
      );
    }

    const data = await updateGalleryService(
      req.params.id,
      galleryData
    );

    return successResponse(
      res,
      "Gallery updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Delete Gallery
// ==========================
export const deleteGallery = async (req, res, next) => {
  try {
    await deleteGalleryService(req.params.id);

    return successResponse(
      res,
      "Gallery deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get Gallery By Portfolio
// ==========================
export const getGalleryByPortfolio = async (req, res, next) => {
  try {
    const data = await getGalleryByPortfolioService(
      req.params.portfolioId
    );

    return successResponse(
      res,
      "Gallery fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Update Display Order
// ==========================
export const updateDisplayOrder = async (req, res, next) => {
  try {
    const data = await updateDisplayOrderService(
      req.params.id,
      req.body.displayOrder
    );

    return successResponse(
      res,
      "Gallery display order updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Toggle Gallery Status
// ==========================
export const toggleGalleryStatus = async (req, res, next) => {
  try {
    const data = await toggleGalleryStatusService(
      req.params.id,
      req.body.status
    );

    return successResponse(
      res,
      "Gallery status updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};