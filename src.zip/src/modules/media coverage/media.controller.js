import {
  createMediaService,
  getAllMediaService,
  getMediaByIdService,
  updateMediaService,
  deleteMediaService,
} from "./media.service.js";

import { successResponse } from "../../utils/response.js";
// import uploadFile from "../../helpers/uploadFile.js";
import uploadFile from "../../utils/uploadFile.js";
// ==========================
// Create Media
// ==========================
export const createMedia = async (req, res, next) => {
  try {
    console.log("BODY =>", req.body);
    console.log("FILES =>", req.files);

    const mediaData = {
      ...req.body,
    };

    // Thumbnail Upload
    if (req.files?.thumbnail?.length > 0) {
      mediaData.thumbnail = await uploadFile(
        req.files.thumbnail[0].path
      );
    }

    // Video Upload
    if (req.files?.video?.length > 0) {
      mediaData.video = await uploadFile(
        req.files.video[0].path
      );
    }

    const data = await createMediaService(mediaData);

    return successResponse(
      res,
      "Media created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get All Media
// ==========================
export const getAllMedia = async (req, res, next) => {
  try {
    const data = await getAllMediaService();

    return successResponse(
      res,
      "Media fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get Media By ID
// ==========================
export const getMediaById = async (req, res, next) => {
  try {
    const data = await getMediaByIdService(req.params.id);

    return successResponse(
      res,
      "Media fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Update Media
// ==========================
export const updateMedia = async (req, res, next) => {
  try {
    console.log("BODY =>", req.body);
    console.log("FILES =>", req.files);

    const mediaData = {
      ...req.body,
    };

    if (req.files?.thumbnail?.length > 0) {
      mediaData.thumbnail = await uploadFile(
        req.files.thumbnail[0].path
      );
    }

    if (req.files?.video?.length > 0) {
      mediaData.video = await uploadFile(
        req.files.video[0].path
      );
    }

    const data = await updateMediaService(
      req.params.id,
      mediaData
    );

    return successResponse(
      res,
      "Media updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Delete Media
// ==========================
export const deleteMedia = async (req, res, next) => {
  try {
    await deleteMediaService(req.params.id);

    return successResponse(
      res,
      "Media deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};