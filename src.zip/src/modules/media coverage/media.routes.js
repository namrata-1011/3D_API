import express from "express";

import {
  createMedia,
  getAllMedia,
  getMediaById,
  updateMedia,
  deleteMedia,
} from "./media.controller.js";

import upload from "../../middleware/upload.middleware.js";

const router = express.Router();

// Create
router.post(
  "/create",
  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
    {
      name: "video",
      maxCount: 1,
    },
  ]),
  createMedia
);

// Get All
router.get("/", getAllMedia);

// Get By ID
router.get("/:id", getMediaById);

// Update
router.put(
  "/:id",
  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
    {
      name: "video",
      maxCount: 1,
    },
  ]),
  updateMedia
);

// Delete
router.delete("/:id", deleteMedia);

export default router;