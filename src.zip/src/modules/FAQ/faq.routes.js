import express from "express";

import {
  createFAQ,
  getAllFAQs,
  getFAQById,
  updateFAQ,
  deleteFAQ,
  createEnquiry,
  getAllEnquiries,
  getEnquiryById,
  replyEnquiry,
  deleteEnquiry,
} from "./faq.controller.js";

const router = express.Router();

// ==============================
// FAQ Routes
// ==============================

router.post("/create", createFAQ);

router.get("/", getAllFAQs);

router.get("/:id", getFAQById);

router.put("/:id", updateFAQ);

router.delete("/:id", deleteFAQ);

// ==============================
// Enquiry Routes
// ==============================

router.post("/enquiry/create", createEnquiry);

router.get("/enquiry", getAllEnquiries);

router.get("/enquiry/:id", getEnquiryById);

router.put("/enquiry/reply/:id", replyEnquiry);

router.delete("/enquiry/:id", deleteEnquiry);

export default router;