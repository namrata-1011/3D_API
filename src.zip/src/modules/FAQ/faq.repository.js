import { FAQ, Enquiry } from "./faq.model.js";

// ==============================
// FAQ Repository
// ==============================

// Create FAQ
export const createFAQRepository = async (payload) => {
  return await FAQ.create(payload);
};

// Get All FAQs
export const getAllFAQRepository = async () => {
  return await FAQ.find().sort({ createdAt: -1 });
};

// Get FAQ By ID
export const getFAQByIdRepository = async (id) => {
  return await FAQ.findById(id);
};

// Update FAQ
export const updateFAQRepository = async (id, payload) => {
  return await FAQ.findByIdAndUpdate(id, payload, {
    new: true,
    runValidators: true,
  });
};

// Delete FAQ
export const deleteFAQRepository = async (id) => {
  return await FAQ.findByIdAndDelete(id);
};

// ==============================
// Enquiry Repository
// ==============================

// Create Enquiry
export const createEnquiryRepository = async (payload) => {
  return await Enquiry.create(payload);
};

// Get All Enquiries
export const getAllEnquiryRepository = async () => {
  return await Enquiry.find().sort({ createdAt: -1 });
};

// Get Enquiry By ID
export const getEnquiryByIdRepository = async (id) => {
  return await Enquiry.findById(id);
};

// Reply Enquiry
export const replyEnquiryRepository = async (id, reply) => {
  return await Enquiry.findByIdAndUpdate(
    id,
    {
      reply,
      status: "Replied",
    },
    {
      new: true,
      runValidators: true,
    }
  );
};

// Delete Enquiry
export const deleteEnquiryRepository = async (id) => {
  return await Enquiry.findByIdAndDelete(id);
};