import {
  createFAQService,
  getAllFAQService,
  getFAQByIdService,
  updateFAQService,
  deleteFAQService,
  createEnquiryService,
  getAllEnquiryService,
  getEnquiryByIdService,
  replyEnquiryService,
  deleteEnquiryService,
} from "./faq.service.js";

import { successResponse } from "../../utils/response.js";

// ==============================
// FAQ Controller
// ==============================

// Create FAQ
export const createFAQ = async (req, res, next) => {
  try {
    const data = await createFAQService(req.body);

    return successResponse(
      res,
      "FAQ created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};

// Get All FAQs
export const getAllFAQs = async (req, res, next) => {
  try {
    const data = await getAllFAQService();

    return successResponse(
      res,
      "FAQs fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// Get FAQ By ID
export const getFAQById = async (req, res, next) => {
  try {
    const data = await getFAQByIdService(req.params.id);

    return successResponse(
      res,
      "FAQ fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// Update FAQ
export const updateFAQ = async (req, res, next) => {
  try {
    const data = await updateFAQService(
      req.params.id,
      req.body
    );

    return successResponse(
      res,
      "FAQ updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// Delete FAQ
export const deleteFAQ = async (req, res, next) => {
  try {
    await deleteFAQService(req.params.id);

    return successResponse(
      res,
      "FAQ deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};

// ==============================
// Enquiry Controller
// ==============================

// Create Enquiry
export const createEnquiry = async (req, res, next) => {
  try {
    const data = await createEnquiryService(req.body);

    return successResponse(
      res,
      "Enquiry created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};

// Get All Enquiries
export const getAllEnquiries = async (req, res, next) => {
  try {
    const data = await getAllEnquiryService();

    return successResponse(
      res,
      "Enquiries fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// Get Enquiry By ID
export const getEnquiryById = async (req, res, next) => {
  try {
    const data = await getEnquiryByIdService(req.params.id);

    return successResponse(
      res,
      "Enquiry fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// Reply Enquiry
export const replyEnquiry = async (req, res, next) => {
  try {
    const data = await replyEnquiryService(
      req.params.id,
      req.body
    );

    return successResponse(
      res,
      "Reply sent successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// Delete Enquiry
export const deleteEnquiry = async (req, res, next) => {
  try {
    await deleteEnquiryService(req.params.id);

    return successResponse(
      res,
      "Enquiry deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};