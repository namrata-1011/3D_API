import uploadFile from "../../utils/uploadFile.js";
import {
  createBlogService,
  getAllBlogService,
  getBlogByIdService,
  updateBlogService,
  deleteBlogService,
} from "./blog.service.js";

import { successResponse } from "../../utils/response.js";

// ==============================
// Create Blog
// ==============================

export const createBlog = async (req, res, next) => {
  try {
    const payload = { ...req.body };

    // Upload Cover Image
    if (req.files?.coverImage) {
      payload.coverImage = await uploadFile(
        req.files.coverImage[0].path,
        "blogs/images"
      );
    }

    // Upload Video
    if (req.files?.video) {
      payload.videoUrl = await uploadFile(
        req.files.video[0].path,
        "blogs/videos"
      );
    }

    const data = await createBlogService(payload);

    return successResponse(
      res,
      "Blog created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};

// ==============================
// Get All Blogs
// ==============================

export const getAllBlogs = async (req, res, next) => {
  try {
    const data = await getAllBlogService();

    return successResponse(
      res,
      "Blogs fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==============================
// Get Blog By ID
// ==============================

export const getBlogById = async (req, res, next) => {
  try {
    const data = await getBlogByIdService(req.params.id);

    return successResponse(
      res,
      "Blog fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==============================
// Update Blog
// ==============================

export const updateBlog = async (req, res, next) => {
  try {
    const payload = { ...req.body };

    // Update Cover Image
    if (req.files?.coverImage) {
      payload.coverImage = await uploadFile(
        req.files.coverImage[0].path,
        "blogs/images"
      );
    }

    // Update Video
    if (req.files?.video) {
      payload.videoUrl = await uploadFile(
        req.files.video[0].path,
        "blogs/videos"
      );
    }

    const data = await updateBlogService(
      req.params.id,
      payload
    );

    return successResponse(
      res,
      "Blog updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==============================
// Delete Blog
// ==============================

export const deleteBlog = async (req, res, next) => {
  try {
    await deleteBlogService(req.params.id);

    return successResponse(
      res,
      "Blog deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};