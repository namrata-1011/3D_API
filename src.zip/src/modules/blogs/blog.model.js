import mongoose from "mongoose";

const blogSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },

    category: {
      type: String,
      enum: [
        "Lifestyle",
        "Marketing",
        "Branding",
        "Creator Journey",
        "Tips",
        "Latest News",
      ],
      default: "Branding",
    },

    author: {
      type: String,
      default: "Akanksha Dua",
      trim: true,
    },

    coverImage: {
      type: String,
      default: "",
    },
    videoUrl: {
      type: String,
      default: "",
    },

    content: {
      type: String,
      required: true,
      trim: true,
    },

    publishDate: {
      type: Date,
      default: Date.now,
    },

    readTime: {
      type: String,
      default: "5 min read",
    },

    status: {
      type: String,
      enum: ["draft", "published"],
      default: "published",
    },

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

export const Blog = mongoose.model("Blog", blogSchema);