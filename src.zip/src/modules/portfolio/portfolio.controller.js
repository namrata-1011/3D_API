import {
  createPortfolioService,
  getAllPortfolioService,
  getPortfolioByIdService,
  updatePortfolioService,
  deletePortfolioService,
  getFeaturedPortfolioService,
  getPortfolioByCategoryService,
} from "./portfolio.service.js";

import { successResponse } from "../../utils/response.js";
// import uploadFile from "../../utils/fileUpload.js";
import uploadFile from "../../utils/uploadFile.js";

// ==========================
// Create Portfolio
// ==========================
export const createPortfolio = async (req, res, next) => {
  try {
    console.log("BODY =>", req.body);
    console.log("FILES =>", req.files);

    let thumbnail = "";
    let images = [];
    let video = "";

    // Upload Thumbnail
    if (req.files?.thumbnail) {
      thumbnail = await uploadFile(req.files.thumbnail[0].path);
    }

    // Upload Multiple Images
    if (req.files?.images) {
      for (const file of req.files.images) {
        const imageUrl = await uploadFile(file.path);
        images.push(imageUrl);
      }
    }

    // Upload Video
    if (req.files?.video) {
      video = await uploadFile(req.files.video[0].path);
    }

    const portfolioData = {
      ...req.body,
      thumbnail,
      images,
      video,
    };

    const data = await createPortfolioService(portfolioData);

    return successResponse(
      res,
      "Portfolio created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get All Portfolio
// ==========================
export const getAllPortfolio = async (req, res, next) => {
  try {
    const data = await getAllPortfolioService();

    return successResponse(
      res,
      "Portfolio fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get Portfolio By ID
// ==========================
export const getPortfolioById = async (req, res, next) => {
  try {
    const data = await getPortfolioByIdService(req.params.id);

    return successResponse(
      res,
      "Portfolio fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Update Portfolio
// ==========================
export const updatePortfolio = async (req, res, next) => {
  try {
    let updateData = {
      ...req.body,
    };

    // Update Thumbnail
    if (req.files?.thumbnail) {
      updateData.thumbnail = await uploadFile(
        req.files.thumbnail[0].path
      );
    }

    // Update Images
    if (req.files?.images) {
      let images = [];

      for (const file of req.files.images) {
        const imageUrl = await uploadFile(file.path);
        images.push(imageUrl);
      }

      updateData.images = images;
    }

    // Update Video
    if (req.files?.video) {
      updateData.video = await uploadFile(
        req.files.video[0].path
      );
    }

    const data = await updatePortfolioService(
      req.params.id,
      updateData
    );

    return successResponse(
      res,
      "Portfolio updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Delete Portfolio
// ==========================
export const deletePortfolio = async (req, res, next) => {
  try {
    await deletePortfolioService(req.params.id);

    return successResponse(
      res,
      "Portfolio deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get Featured Portfolio
// ==========================
export const getFeaturedPortfolio = async (req, res, next) => {
  try {
    const data = await getFeaturedPortfolioService();

    return successResponse(
      res,
      "Featured Portfolio fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};

// ==========================
// Get Portfolio By Category
// ==========================
export const getPortfolioByCategory = async (req, res, next) => {
  try {
    const data = await getPortfolioByCategoryService(
      req.params.category
    );

    return successResponse(
      res,
      "Portfolio category fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};