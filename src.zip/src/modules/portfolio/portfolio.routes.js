import express from "express";

import {
  createPortfolio,
  getAllPortfolio,
  getPortfolioById,
  updatePortfolio,
  deletePortfolio,
  getFeaturedPortfolio,
  getPortfolioByCategory,
} from "./portfolio.controller.js";

import upload from "../../middleware/upload.middleware.js";

const router = express.Router();


// Create Portfolio
router.post(
  "/create",
  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
    {
      name: "images",
      maxCount: 5,
    },
    {
      name: "video",
      maxCount: 1,
    },
  ]),
  createPortfolio
);


// Get All
router.get("/", getAllPortfolio);


// Featured
router.get("/featured", getFeaturedPortfolio);


// Category
router.get("/category/:category", getPortfolioByCategory);


// Get By ID
router.get("/:id", getPortfolioById);


// Update Portfolio
router.put(
  "/:id",
  upload.fields([
    {
      name: "thumbnail",
      maxCount: 1,
    },
    {
      name: "images",
      maxCount: 5,
    },
    {
      name: "video",
      maxCount: 1,
    },
  ]),
  updatePortfolio
);


// Delete
router.delete("/:id", deletePortfolio);


export default router;