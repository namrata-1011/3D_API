import {
  createTestimonialService,
  getAllTestimonialsService,
  getTestimonialByIdService,
  updateTestimonialService,
  deleteTestimonialService,
} from "./testimonial.service.js";

import { successResponse } from "../../utils/response.js";
// Create Testimonial
export const createTestimonial = async (req, res, next) => {
  try {
    const data = await createTestimonialService(req.body);

    return successResponse(
      res,
      "Testimonial created successfully",
      data,
      201
    );
  } catch (error) {
    next(error);
  }
};
// Get All Testimonials
export const getAllTestimonials = async (req, res, next) => {
  try {
    const data = await getAllTestimonialsService();

    return successResponse(
      res,
      "Testimonials fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};
// Get Testimonial By ID
export const getTestimonialById = async (req, res, next) => {
  try {
    const data = await getTestimonialByIdService(req.params.id);

    return successResponse(
      res,
      "Testimonial fetched successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};
// Update Testimonial
export const updateTestimonial = async (req, res, next) => {
  try {
    const data = await updateTestimonialService(
      req.params.id,
      req.body
    );

    return successResponse(
      res,
      "Testimonial updated successfully",
      data
    );
  } catch (error) {
    next(error);
  }
};
// Delete Testimonial
export const deleteTestimonial = async (req, res, next) => {
  try {
    await deleteTestimonialService(req.params.id);

    return successResponse(
      res,
      "Testimonial deleted successfully",
      null
    );
  } catch (error) {
    next(error);
  }
};