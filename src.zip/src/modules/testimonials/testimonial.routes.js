import express from "express";

import {
  createTestimonial,
  getAllTestimonials,
  getTestimonialById,
  updateTestimonial,
  deleteTestimonial,
} from "./testimonial.controller.js";

const router = express.Router();

// Create
router.post("/create", createTestimonial);

// Get All
router.get("/", getAllTestimonials);

// Get By ID
router.get("/:id", getTestimonialById);

// Update
router.put("/:id", updateTestimonial);

// Delete
router.delete("/:id", deleteTestimonial);

export default router;